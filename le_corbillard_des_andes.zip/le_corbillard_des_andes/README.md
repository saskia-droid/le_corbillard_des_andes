## EGJ 2026

```
docker run -it --rm -v $PWD:/src devkitpro/devkitarm bash
```

setting the environnment:

```
export DEVKITPRO=/opt/devkitpro
export DEVKITARM=$DEVKITPRO/devkitARM
export PATH=$DEVKITARM/bin:$PATH
```

pr compil les images: 
``` 
grit player.png -gb -gB16
``` 

