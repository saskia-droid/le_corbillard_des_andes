#ifndef PLAYER_H
#define PLAYER_H

typedef struct
{
    int x;
    int y;

    int width;
    int height;
	
	int hasChinchilla;

} Player;

void playerInit(Player *player);

void playerUpdate(Player *player);

void playerDraw(Player *player);

#endif