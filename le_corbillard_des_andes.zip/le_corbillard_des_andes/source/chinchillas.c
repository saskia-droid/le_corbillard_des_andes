#include <stdlib.h>

#include "chinchillas.h"
#include "graphics.h"
#include "parapentiste.h"
#include "player.h"

#define MAGENTA RGB5(31,0,31)

Chinchilla chinchillas[NB_CHINCHILLAS];

void chinchillasInit(void)
{
	
	for (int i = 0; i < NB_CHINCHILLAS;  i++)
	{
		chinchillas[i].width = 32;
		chinchillas[i].height = 32;
		
		chinchillas[i].carried = 0;
		
		chinchillas[i].x = rand() % (SCREEN_WIDTH - chinchillas[i].width);
		
		// start above the screen 
		chinchillas[i].y = -chinchillas[i].height; 
		
		chinchillas->targetX = rand() % (SCREEN_WIDTH - chinchillas[i].width);
		chinchillas->targetY = SCREEN_HEIGHT * 2 / 3 + rand() % 40;
		
		chinchillas[i].active = 0; // leave the chinchilla inactive
		//chinchillas[i].moving = 1;
	}
}

void chinchillasUpdate(void)
{
	int stopY = SCREEN_HEIGHT * 2 /3;
	
	for (int i = 0; i < NB_CHINCHILLAS; i++)
	{
		if (chinchillas[i].moving)
		{
			if (chinchillas[i].x < chinchillas[i].targetX)
			    chinchillas[i].x++;

			if (chinchillas[i].x > chinchillas[i].targetX)
			    chinchillas[i].x--;

			if (chinchillas[i].y < chinchillas[i].targetY)
			    chinchillas[i].y++;
			
			if (chinchillas[i].y >= stopY)
			{
				chinchillas[i].y = stopY;
				chinchillas[i].moving = 0;
			}
		}
	}
}

void chinchillasSpawn(void)
{
    for (int i = 0; i < NB_CHINCHILLAS; i++)
    {
        if (!chinchillas[i].active)
        {
            chinchillas[i].active = 1;
            chinchillas[i].moving = 1;

            chinchillas[i].x = rand() % (SCREEN_WIDTH - 32);
            chinchillas[i].y = -32;

            chinchillas[i].targetX = rand() % (SCREEN_WIDTH - 32);
            chinchillas[i].targetY = 110 + rand() % 40;

            return;
        }
    }
}

void chinchillasPickup(Player *player)
{
	for (int i = 0; i < NB_CHINCHILLAS; i++)
	{
		int dx = player->x - chinchillas[i].x;
		int dy = player->y - chinchillas[i].y;
		
		if (dx < 20 && dx > -20 && dy < 20 && dy > -20)
		{
			if (!player->hasChinchilla)
			{
				if (chinchillas[i].active && !chinchillas[i].carried)
				{
					chinchillas[i].active = 0;
					chinchillas[i].carried = 1;
						
					player->hasChinchilla = 1;
				}
			}
		}
	}
}

void chinchillasDraw(void)
{
	for (int i = 0; i < NB_CHINCHILLAS; i++)
	{
		if (chinchillas[i].active)
		{
			if (chinchillas[i].moving)
				drawImage(
			        	chinchillas[i].x,
			        	chinchillas[i].y,
			        	32,
			        	32,
			        	(const u16*)parapentisteBitmap,
			        	0,
			        	MAGENTA);
			else
				drawImage(
					chinchillas[i].x,
			        chinchillas[i].y,
			        32,
			        32,
			        (const u16*)parapentisteBitmap,
			        32,
			        MAGENTA);
			
		}
	}
}