
//{{BLOCK(corbillard)

//======================================================================
//
//	corbillard, 32x32@16, 
//	+ bitmap not compressed
//	Total size: 2048 = 2048
//
//	Time-stamp: 2026-07-04, 17:58:50
//	Exported by Cearn's GBA Image Transmogrifier, v0.9.2
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_CORBILLARD_H
#define GRIT_CORBILLARD_H

#define corbillardBitmapLen 2048
extern const unsigned int corbillardBitmap[512];

#endif // GRIT_CORBILLARD_H

//}}BLOCK(corbillard)
