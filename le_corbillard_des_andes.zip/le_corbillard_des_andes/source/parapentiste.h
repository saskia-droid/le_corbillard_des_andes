
//{{BLOCK(parapentiste)

//======================================================================
//
//	parapentiste, 32x64@16, 
//	+ bitmap not compressed
//	Total size: 4096 = 4096
//
//	Time-stamp: 2026-07-04, 23:09:18
//	Exported by Cearn's GBA Image Transmogrifier, v0.9.2
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PARAPENTISTE_H
#define GRIT_PARAPENTISTE_H

#define parapentisteBitmapLen 4096
extern const unsigned int parapentisteBitmap[1024];

#endif // GRIT_PARAPENTISTE_H

//}}BLOCK(parapentiste)
