
//{{BLOCK(background)

//======================================================================
//
//	background, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2026-07-04, 17:58:40
//	Exported by Cearn's GBA Image Transmogrifier, v0.9.2
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BACKGROUND_H
#define GRIT_BACKGROUND_H

#define backgroundBitmapLen 76800
extern const unsigned int backgroundBitmap[19200];

#endif // GRIT_BACKGROUND_H

//}}BLOCK(background)
