
//{{BLOCK(background_plus)

//======================================================================
//
//	background_plus, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2026-07-05, 12:11:36
//	Exported by Cearn's GBA Image Transmogrifier, v0.9.2
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BACKGROUND_PLUS_H
#define GRIT_BACKGROUND_PLUS_H

#define background_plusBitmapLen 76800
extern const unsigned int background_plusBitmap[19200];

#endif // GRIT_BACKGROUND_PLUS_H

//}}BLOCK(background_plus)
