#ifndef CHINCHILLAS_H
#define CHINCHILLAS_H 

#include <gba_video.h>
#include "player.h"

#define NB_CHINCHILLAS 3

typedef struct
{
	int x; 
	int y; 
	
	int targetX;
	int targetY;
	
	int width;
	int height;
	 
	int moving;
	int active;
	
	int carried;
	
} Chinchilla;

void chinchillasInit(void);

void chinchillasUpdate(void);

void chinchillasSpawn(void);

void chinchillasPickup(Player *player);

void chinchillasDraw(void);

#endif