#ifndef TOMBSTONES_H
#define TOMBSTONES_H

#define MAX_TOMBSTONES 20

typedef struct
{
    int x;
    int y;
    int active;
} Tombstone;

void tombstonesInit(void);
void tombstonesDraw(void);
void tombstonesPlace(int x, int y);

#endif