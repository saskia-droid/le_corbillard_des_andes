#include "tombstones.h"
#include "tumbstone.h"
#include "graphics.h"

#define MAGENTA RGB5(31,0,31)

static Tombstone tombstones[MAX_TOMBSTONES];

void tombstonesInit(void)
{
	for(int i = 0; i < MAX_TOMBSTONES; i++)
	{
		tombstones[i].active = 0;
	}
}

void tombstonesPlace(int x, int y)
{
	for(int i = 0; i < MAX_TOMBSTONES; i++)
	{
		if(!tombstones[i].active)
		{
			tombstones[i].active = 1;
			
			tombstones[i].x = x;
			tombstones[i].y = y;
			
			return;
		}
	}
}

void tombstonesDraw(void)
{
	for(int i = 0; i < MAX_TOMBSTONES; i++)
	{
		if(tombstones[i].active)
		{
			drawImage(
				tombstones[i].x,
		        tombstones[i].y,
		        32,
		        32,
		        (const u16*)tumbstoneBitmap,
		        0,
		        MAGENTA);
		}
	}
}