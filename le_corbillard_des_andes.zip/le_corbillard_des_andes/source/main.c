#include <gba_console.h>
#include <gba_systemcalls.h>
#include <gba_interrupt.h>
#include <gba_input.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <maxmod.h>
#include "soundbank.h"
#include "soundbank_bin.h"

#define BLACK RGB5(0,0,0)
#define GREEN RGB5(0,31,0)

#include "game.h"

#include "background_plus.h"
#include "corbillard.h"
#include "accueil.h"

#include "graphics.h"
#include "chinchillas.h"
#include "player.h"
#include "tombstones.h"

#define KEY_DOWN_NOW(key) (!(REG_KEYINPUT & (key)))

int main(void)
{
	
	srand(42); // Fixed seed: repeatable behavior
	
    REG_DISPCNT = MODE_3 | BG2_ENABLE; //turn the screen on and tell it how to interpret VRAM

	irqInit(); // to make the VBlankIntrWait(); more or less works
	irqSet (IRQ_VBLANK, mmVBlank);
	irqEnable(IRQ_VBLANK); // to make the VBlankIntrWait(); more or less works
	
	mmInitDefault(
	    (mm_addr)soundbank_bin,
	    8);
	
	GameState state = GAME_TITLE;
	
	int frameCounter = 0;
	
	Player corbillard;
	
	playerInit(&corbillard);
	chinchillasInit();
	tombstonesInit();

	mmStart(
	    MOD_CORBILLARD_DES_ANDES,
	    MM_PLAY_LOOP);

    while (1)
    {
		
		VBlankIntrWait(); //wait until the next safe frame moment
		mmFrame();
		
		switch (state)
		{
			case GAME_TITLE:
			
				memcpy((void*)VRAM, accueilBitmap, accueilBitmapLen);
				
				if (KEY_DOWN_NOW(KEY_START))
				{
					state = GAME_PLAYING;
				}
				
				break;
				
			case GAME_PLAYING: 
		
		frameCounter++;
		
		if (frameCounter % 60 == 0)
		{
			chinchillasSpawn();
		}

		if (KEY_DOWN_NOW(KEY_A))
		{
			chinchillasPickup(&corbillard);
		}

		if (KEY_DOWN_NOW(KEY_B))
		{
			if(corbillard.hasChinchilla)
			{
				tombstonesPlace(corbillard.x, corbillard.y);
				corbillard.hasChinchilla = 0;
			}
		}

		chinchillasUpdate();
		playerUpdate(&corbillard);
		
		//draw background
		memcpy((void*)VRAM, background_plusBitmap, background_plusBitmapLen);
		//fillScreen();

		tombstonesDraw();
		chinchillasDraw();
		playerDraw(&corbillard);
		
		break;
		
		}	
    }

    return 0;
}