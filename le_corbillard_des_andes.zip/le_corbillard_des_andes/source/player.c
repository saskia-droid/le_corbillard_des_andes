#include "player.h"

#include <gba_input.h>

#include "graphics.h"
#include "corbillard.h"

#define MAGENTA RGB5(31,0,31)

#define KEY_DOWN_NOW(key) (!(REG_KEYINPUT & (key)))

void playerInit(Player *player)
{
	player->x = 110;
	player->y = 110;
	
	player->width = 32;
	player->height = 32;
	
	player->hasChinchilla = 0;
}

void playerUpdate(Player *player)
{
	// move
	if (KEY_DOWN_NOW(KEY_LEFT))
		player->x--;
	if (KEY_DOWN_NOW(KEY_RIGHT))
		player->x++;
	if (KEY_DOWN_NOW(KEY_UP))
		player->y--;
	if (KEY_DOWN_NOW(KEY_DOWN))
		player->y++;
		
	// keep box on screen
	if (player->x < 0)
		player->x = 0;
	if (player->y < SCREEN_HEIGHT * 2 / 3 - 16)
		player->y = SCREEN_HEIGHT * 2 / 3 - 16; 
	if (player->x > SCREEN_WIDTH - player->width)
		player->x = SCREEN_WIDTH - player->width;
	if (player->y > SCREEN_HEIGHT - player->height)
		player->y = SCREEN_HEIGHT - player->height;
}

void playerDraw(Player *player)
{
    drawImage(
        player->x,
        player->y,
        player->width,
        player->height,
        (const u16*)corbillardBitmap,
		0,
        MAGENTA
    );
}