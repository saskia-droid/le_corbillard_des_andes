#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <gba_video.h>

#define SCREEN_WIDTH 240
#define SCREEN_HEIGHT 160

void drawPixel(int x, int y, u16 color);

void drawRect(int x, int y,
              int width,
              int height,
              u16 color);

void drawImage(int x, int y,
               int width,
               int height,
               const u16 *image,
			   int sourceY,
               u16 transparentColor);

#endif