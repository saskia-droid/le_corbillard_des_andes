
//{{BLOCK(accueil)

//======================================================================
//
//	accueil, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2026-07-05, 10:16:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.9.2
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ACCUEIL_H
#define GRIT_ACCUEIL_H

#define accueilBitmapLen 76800
extern const unsigned int accueilBitmap[19200];

#endif // GRIT_ACCUEIL_H

//}}BLOCK(accueil)
