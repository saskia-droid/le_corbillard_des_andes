#ifndef GAME_H
#define GAME_H

typedef enum
{
    GAME_TITLE,
    GAME_PLAYING
} GameState;

#endif