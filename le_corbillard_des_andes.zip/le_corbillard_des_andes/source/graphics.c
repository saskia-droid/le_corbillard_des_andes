#include "graphics.h"

void drawPixel(int x, int y, u16 color)
{
    ((u16*)VRAM)[y * SCREEN_WIDTH + x] = color;
}

void drawRect(int x, int y, int width, int height, u16 color)
{
    for(int row = 0; row < height; row++)
    {
        for(int col = 0; col < width; col++)
        {
			int px = x + col;
			int py = y + row;
			
			if (px >= 0 && px < SCREEN_WIDTH && 
				py >= 0 && py < SCREEN_HEIGHT)
			{
				drawPixel(px, py, color);
			}
        }
    }
}

void drawImage(int x, int y,
               int width,
               int height,
               const unsigned short *image,
			   int sourceY, 
			   u16 transparentColor)
{
    for(int row = 0; row < height; row++)
    {
        for(int col = 0; col < width; col++)
        {
			u16 pixel = image[(sourceY + row) * width + col];
			
			if (pixel != transparentColor)
			{
            ((u16*)VRAM)[(y+row)*SCREEN_WIDTH + x + col] =
                pixel;
			}
        }
    }
}