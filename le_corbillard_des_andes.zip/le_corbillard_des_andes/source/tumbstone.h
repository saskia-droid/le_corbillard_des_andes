
//{{BLOCK(tumbstone)

//======================================================================
//
//	tumbstone, 32x32@16, 
//	+ bitmap not compressed
//	Total size: 2048 = 2048
//
//	Time-stamp: 2026-07-05, 10:42:39
//	Exported by Cearn's GBA Image Transmogrifier, v0.9.2
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TUMBSTONE_H
#define GRIT_TUMBSTONE_H

#define tumbstoneBitmapLen 2048
extern const unsigned int tumbstoneBitmap[512];

#endif // GRIT_TUMBSTONE_H

//}}BLOCK(tumbstone)
